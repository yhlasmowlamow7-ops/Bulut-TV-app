package tm.bulut.tv

import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import org.json.JSONObject

data class Ch(val id: String, val name: String, val country: String, val category: String, val logo: String, val url: String)

val BG = Color(0xFF1C1312)
val CARD = Color(0xFF2A1F1D)
val ACC = Color(0xFFF5A524)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = 0xFF1C1312.toInt()
        window.navigationBarColor = 0xFF1C1312.toInt()
        val list = loadChannels()
        setContent { BulutApp(list) }
    }

    private fun loadChannels(): List<Ch> {
        val txt = assets.open("channels.json").bufferedReader().use { it.readText() }
        val root = JSONObject(txt)
        val arr = root.getJSONArray(root.keys().next())
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Ch(o.optString("id"), o.optString("name"), o.optString("country"),
                o.optString("category"), o.optString("logo"), o.optString("url"))
        }
    }
}

@Composable
fun BulutApp(all: List<Ch>) {
    var playing by remember { mutableStateOf<Ch?>(null) }
    MaterialTheme(colorScheme = darkColorScheme(primary = ACC, background = BG, surface = CARD)) {
        Surface(Modifier.fillMaxSize(), color = BG) {
            val p = playing
            if (p != null) PlayerScreen(p) { playing = null }
            else Home(all) { playing = it }
        }
    }
}

@Composable
fun Home(all: List<Ch>, onPick: (Ch) -> Unit) {
    var country by remember { mutableStateOf("all") }
    var query by remember { mutableStateOf("") }
    val tabs = listOf("all" to "Ählisi", "tm" to "🇹🇲 Türkmen", "ru" to "🇷🇺 Rus", "tr" to "🇹🇷 Türk")
    val shown = all.filter {
        (country == "all" || it.country == country) && it.name.contains(query, ignoreCase = true)
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 12.dp)) {
        Text("Bulut TV", color = ACC, fontSize = 28.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 12.dp))
        Text("${all.size} kanal göni efirde", color = Color(0xFFBBA79A), fontSize = 13.sp)
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Kanal gözle") },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tabs) { (key, label) ->
                FilterChip(selected = country == key, onClick = { country = key }, label = { Text(label) })
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(140.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            items(shown, key = { it.id }) { ch ->
                Column(
                    Modifier.clip(RoundedCornerShape(16.dp)).background(CARD)
                        .clickable { onPick(ch) }.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    AsyncImage(model = ch.logo, contentDescription = ch.name,
                        contentScale = ContentScale.Fit, modifier = Modifier.size(72.dp))
                    Spacer(Modifier.height(6.dp))
                    Text(ch.name, color = Color.White, fontSize = 14.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                    Text(ch.category, color = ACC, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun PlayerScreen(ch: Ch, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val act = ctx as Activity
    val player = remember { ExoPlayer.Builder(ctx).build() }
    var error by remember { mutableStateOf<String?>(null) }

    DisposableEffect(ch.url) {
        error = null
        player.addListener(object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) { error = "Kanal açylmady" }
        })
        player.setMediaItem(MediaItem.fromUri(ch.url))
        player.prepare()
        player.playWhenReady = true
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val c = WindowInsetsControllerCompat(act.window, act.window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            c.show(WindowInsetsCompat.Type.systemBars())
            player.release()
        }
    }
    BackHandler(onBack = onClose)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { PlayerView(it).apply { this.player = player; useController = true; keepScreenOn = true } },
            modifier = Modifier.fillMaxSize()
        )
        Row(Modifier.align(Alignment.TopStart).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("● GÖNI ÝAÝLYM", color = Color.Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
            Text(ch.name, color = Color.White, fontSize = 13.sp)
        }
        error?.let {
            Text(it, color = ACC, modifier = Modifier.align(Alignment.Center), fontSize = 16.sp)
        }
    }
}
